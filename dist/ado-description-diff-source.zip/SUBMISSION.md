# Firefox Add-ons submission — version 1.0.2

## Version notes

- Hardened description rendering with bundled DOMPurify. Description HTML is sanitized before calculating diffs and again before displaying or copying the result.
- Replaced toolbar HTML assignments with DOM construction and text labels.
- Preserved inline and side-by-side diffs, rich-text formatting, tables, safe links, and images. Generated views omit active content and inline styles.
- Added the Firefox data collection declaration, author dawiisss (K3to), and homepage https://github.com/dawiisss/.
- Set the Firefox add-on ID to `ado-description-diff@dawiisss`.

## Notes to reviewers

This extension changes the display of Description revisions in the Azure DevOps Work Item History tab. It does not edit work items or upload description text. Preferences and configured hostnames use browser sync storage when available. Description images may still load from their original servers.

DOMPurify 3.4.17 is bundled without modifications as `content/vendor/purify.js`, alongside its license. Both input HTML and the diff engine output pass through DOMPurify with a restricted formatting allowlist. Rendered HTML uses sanitized document fragments; toolbar controls use native DOM methods. No remote scripts are loaded.

The HTML diff engine (`content/htmldiff.js`) is adapted from the open-source library htmldiff.js (https://github.com/tnwinc/htmldiff.js, MIT License), wrapped with a standalone UMD wrapper and split-view generation without external runtime dependencies.

The original distribution of DOMPurify is https://github.com/cure53/DOMPurify/blob/3.4.17/dist/purify.js and readable upstream sources are at https://github.com/cure53/DOMPurify/tree/3.4.17/src. The exact npm dependency is pinned in `package.json` and `package-lock.json`.

The local Mozilla add-ons validator reports no errors and three warnings. The remaining `UNSAFE_VAR_ASSIGNMENT` warning points to line 1849 in the unmodified DOMPurify library, where its internal parser falls back to a detached document before sanitization. No first-party extension code assigns HTML to `innerHTML`. The other two warnings concern `data_collection_permissions` on Firefox versions older than 140 (desktop) and 142 (Android). The minimum desktop version remains 109; description processing stays local on older versions as well.

To build, use Node.js 20 or later, npm, and Python 3 on Linux or macOS, then run `npm ci` and `npm run package` from the project root. The packaging script uses `/tmp` and the `python3` command. The installable output is `dist/ado-description-diff.zip`. Upload `dist/ado-description-diff-source.zip` as the separate source package. It includes the demo, build instructions, and original DOMPurify package with its readable sources and licenses.

To test with Azure DevOps:

1. Install the extension and sign in to an Azure DevOps project.
2. Open a work item with at least two different Description revisions and select History.
3. Verify inserted and deleted words in Inline and Side-by-Side views.
4. Switch revisions, toggle Original, try Focus Changes, and copy the current description.
5. Check that disabling the extension restores the native History display.

A live Azure DevOps project requires access. Supply a dedicated test account and the test work-item URL privately in AMO's Notes to Reviewer if required. No credentials are included in this project.

For an account-free supplemental demonstration, extract the source ZIP and open `demo/testbed.html`. It loads the same sanitizer, diff engine, and content script locally. Use the revision switcher and theme and tab controls to exercise the display behavior. The demo is not included in the installable extension ZIP and does not replace live account credentials when reviewers need them.
