# Version 1.0.3

Released on **22 October 2026**. These notes describe the 1.0.3 release and its validation status.

Add Acceptance Criteria diffs alongside Description, using the same History detection and sanitized rendering for both fields.

- Recognise Acceptance Criteria by its display label, `AcceptanceCriteria` alias, and `Microsoft.VSTS.Common.AcceptanceCriteria` reference name.
- Support native `.html-field-diff` bodies, old/new table rows, and activity feeds.
- Use the appropriate field name in widget titles, Copy labels and feedback, and empty-state text.
- Keep each field's view controls and source restoration independent within the same revision.
- Preserve filter/editor isolation, native whole-value wrapper extraction, and source DOM restoration.
- Include `CHANGELOG.md` in the installable and reviewer source archives.
- Update popup and Options wording and version labels to 1.0.3.

No new extension permissions or network calls are introduced.

## Verification

All 12 diff-engine tests, 23 DOM tests, and JavaScript syntax checks passed. The DOM tests execute the actual bundled sanitizer, engine, and content script, and include the supplied Description HTML plus Acceptance Criteria fixtures. Visibility geometry is simulated; they do not verify rendering. Browser regressions also cover native markdown values, restoration, both supported fields, and isolation. The sandbox prevents Chromium from launching, so browser rendering and the authenticated live page remain unverified.

`jsdom` is a development-only dependency for reproducible DOM tests. It is not included in the installable extension and introduces no extension permissions or runtime network requests. Run `npm run test:unit` for the diff-engine and DOM checks without Chromium.

## Manual review

1. Load the extension, refresh Azure DevOps, and open a work item's History.
2. Open the field filter. Description and other options must remain native controls with no diff toolbar.
3. Select a revision that changes Description and Acceptance Criteria. Check that each widget has the correct field name and independent Inline, Side-by-Side, and Original controls.
4. Switch revisions and switch to Details. Check restoration and that editors remain untouched.
5. Check added-only and removed-only Acceptance Criteria, Copy feedback, and that updating one field does not mix its content with the other.
6. Verify against the affected Azure DevOps instance. If a change is not detected, capture its surrounding HTML with work-item text redacted and retain tags, classes, and roles.

The ZIP is unsigned; Firefox permanent installation requires Mozilla signing.
